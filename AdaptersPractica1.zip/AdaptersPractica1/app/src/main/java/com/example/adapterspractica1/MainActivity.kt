package com.example.adapterspractica1

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var listView: ListView
    lateinit var spinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val arrayAdapter: ArrayAdapter<*>
        val arr=arrayOf("Python", "C", "Rust", "C++", "Java", "Kotlin", "JavaScript")

        listView = findViewById<ListView>(R.id.listView)
        spinner = findViewById<Spinner>(R.id.spinner)


        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, arr)

        listView.adapter = arrayAdapter

        listView.setOnItemClickListener{
                parent, view, position, id ->
            val lenguajeSelect=arr[position]
            Toast.makeText(this, "Seleccionaste: ", Toast.LENGTH_LONG).show()
        }


        val semana = resources.getStringArray(R.array.semana)

        val adapter = arrayAdapter(this, android.R.layout.simple_spinner_item, semana)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}